# NBA Halftime Alerts: Setup Guide

About 15 minutes, no coding. You'll need a free GitHub account.

## What this does
A small script runs on GitHub's free servers, checks live NBA scores every 30 seconds, and pushes a notification to your iPhone the moment a game hits halftime (with the score). Each game alerts once.

## Step 1: Install ntfy on your iPhone
1. Install **ntfy** from the App Store (free).
2. Open it, tap **+**, and subscribe to a topic. The topic name is like a password, so make it long and unguessable, for example `halftime-brian-7k2x9q4m`. Write it down.
3. Allow notifications when iOS asks.

## Step 2: Create a GitHub repository
1. Go to github.com and sign in (or sign up).
2. Click **+** (top right) > **New repository**.
3. Name it `nba-halftime`. Choose **Public** (this keeps the free run time unlimited; your topic name stays private in Step 4, so nobody can see it).
4. Click **Create repository**.

## Step 3: Upload the files
1. On the new repository page, click **uploading an existing file**.
2. Drag in `notify.py` and the whole `.github` folder from the folder I gave you. (If your computer hides folders starting with a dot, turn on "show hidden files": press Cmd+Shift+. on a Mac.)
3. Click **Commit changes**.

## Step 4: Add your topic as a secret
1. In the repository, go to **Settings > Secrets and variables > Actions**.
2. On the **Secrets** tab click **New repository secret**.
3. Name: `NTFY_TOPIC`. Value: the topic from Step 1. Click **Add secret**.

## Step 5: Send a test
1. Open the **Actions** tab. If asked, click the button to enable workflows.
2. Click **Send test notification** on the left, then **Run workflow**.
3. Within about a minute your iPhone should buzz. If it does, everything is connected.

## Step 6: Start the alerts
1. In the **Actions** tab, click **NBA halftime alerts** > **Run workflow** to start watching right away.
2. After that it starts itself twice a day (about 1 PM and 7 PM Eastern) and runs about 6 hours each time.

## Only want certain teams? (optional)
Go to **Settings > Secrets and variables > Actions > Variables** tab > **New repository variable**. Name: `TEAMS`. Value: team abbreviations separated by commas, for example `NY,BOS,LAL`. Leave it unset for all games.

## Good to know
- **Daylight saving:** clocks change Nov 1. After that the two start times shift to 12 PM and 6 PM Eastern, which still covers games.
- **Delays:** GitHub sometimes starts scheduled runs a few minutes late, and rarely skips one. If you miss alerts, use **Run workflow** to start it by hand.
- **Inactivity:** GitHub pauses scheduled workflows after 60 days with no repository activity. If alerts stop, open the Actions tab and re-enable them.
- **Data source:** this uses ESPN's public scoreboard feed, which is unofficial and could change someday. If alerts stop working, tell me and I'll adjust the script.
